Files for manufacture:

Board2.GBL - Bottom copper layer
Board2.GBO - Bottom overlay (silkscreen)
Board2.GBS - Bottom soldermask
Board2.G1 - Internal plane 2 (i.e. just below top layer)
Board2.G2 - Internal plane 3 (i.e. just above bottom layer)
Board2.GTL - Top copper layer
Board2.GTO - Top overlay (silkscreen)
Board2.GTS - Top soldermask
Board2.txt - NC drill file
README.txt - This text file

Notes:

Contact details:
Henry Jenkins
Electrical and Computer Engineering
University of Canterbury
hvj10@uclive.av.nz
+64273698211

