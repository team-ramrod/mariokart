Files for manufacture:

Motor Board.DRL - Binary NC drill file
Motor Board.GBL - Bottom copper layer
Motor Board.GBO - Bottom overlay (silkscreen)
Motor Board.GBS - Bottom soldermask
Motor Board.G1 - Internal plane 2 (i.e. just below top layer)
Motor Board.G2 - Internal plane 3 (i.e. just above bottom layer)
Motor Board.GTL - Top copper layer
Motor Board.GTO - Top overlay (silkscreen)
Motor Board.GTS - Top soldermask
Motor Board.txt - NC drill file
README.txt - This text file

Notes:

Contact details:
Henry Jenkins
Electrical and Computer Engineering
University of Canterbury
hvj10@uclive.av.nz
+64273698211

