Files for manufacture:

Board1.GBL - Bottom copper layer
Board1.GBO - Bottom overlay (silkscreen)
Board1.GBS - Bottom soldermask
Board1.G1 - Internal plane 2 (i.e. just below top layer)
Board1.G2 - Internal plane 3 (i.e. just above bottom layer)
Board1.GTL - Top copper layer
Board1.GTO - Top overlay (silkscreen)
Board1.GTS - Top soldermask
Board1.txt - NC drill file
README.txt - This text file

Notes:

Contact details:
Henry Jenkins
Electrical and Computer Engineering
University of Canterbury
hvj10@uclive.av.nz
+64273698211

